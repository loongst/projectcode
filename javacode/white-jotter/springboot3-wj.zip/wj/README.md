## springboot3项目

包含基本的登录、注册、密码重置等功能，可以二次开发邪具体场景下的应用程序。

*登录功能（支持用户名、邮箱）

*注册用户（通过邮箱注册）

*重置密码（通过邮箱重置密码）


**1、java17**

**2、springboot3**

**3、maven3.8.x**

**4、swagger3**

https://springdoc.org/v2/
```
<dependency>
<groupId>org.springdoc</groupId>
<artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
<version>2.1.0</version>
</dependency>
```

**5、actuator**

https://www.pianshen.com/article/24562406838/
```
<dependency>
<groupId>org.springframework.boot</groupId>
<artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```
```
management.server.port=8081
management.endpoints.web.exposure.include=*
management.endpoints.shutdown.enable=true
management.endpoints.env.enabled= true
```